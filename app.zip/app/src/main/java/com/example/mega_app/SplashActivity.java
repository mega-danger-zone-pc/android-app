package com.example.mega_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;

public class SplashActivity extends AppCompatActivity {
    final int interval = 30;
    final int total = 3000;
    final int steps = total / interval;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ProgressBar progressBar = findViewById(R.id.linearProgressIndicator);
        TextView text = findViewById(R.id.textProc);

        final Handler progressHandler = new Handler();
        progressHandler.post(new Runnable() {
            int progress = 0;
            @Override
            public void run() {
                progress += 100 / steps;
                progressBar.setProgress(progress);
                text.setText(progress + "%");

                if (progress < 100) {
                    progressHandler.postDelayed(this, 30);
                } else {
                    startActivity(new Intent(SplashActivity.this, MainActivity.class));
                    finish();
                }
            }
        });
    }
}