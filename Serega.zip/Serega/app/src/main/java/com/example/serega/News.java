package com.example.serega;

public class News {
    String zagolovok, textik, data;
    int kartinka;
    public News(String zagolovok, String textik, String data, int kartinka) {
        this.zagolovok = zagolovok;
        this.textik = textik;
        this.data = data;
        this.kartinka = kartinka;
    }
}
