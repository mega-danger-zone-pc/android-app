package com.example.serega;

import android.graphics.Paint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class CardFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_card, container, false);

        TextView toolbarTitle = rootView.findViewById(R.id.toolbar_title);
        toolbarTitle.setText("Detail Product");

        TextView name = rootView.findViewById(R.id.tma_2hd_wir);
        TextView price = rootView.findViewById(R.id.cena);
        TextView cenaold = rootView.findViewById(R.id.cenaold);
        ImageView img = rootView.findViewById(R.id.avavvava);
        ImageView sale = rootView.findViewById(R.id.salo);

        rootView.findViewById(R.id.back_button).setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        if (getArguments() != null) {
            ItemCard itemCard = getArguments().getParcelable("itemCard");
            if (itemCard != null) {
                name.setText(itemCard.title);
                if (itemCard.skidka_cena > 0) {
                    cenaold.setVisibility(View.VISIBLE);
                    sale.setVisibility(View.VISIBLE);
                    cenaold.setPaintFlags(cenaold.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                    cenaold.setText(String.format("Rp. %,.0f", itemCard.cena));
                    price.setText(String.format("Rp. %,.0f", itemCard.skidka_cena));
                }
                else price.setText(String.format("Rp. %,.0f", itemCard.cena));
                img.setImageResource(itemCard.image);
            }
        }
        return rootView;
    }
}