package com.example.serega;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ResetActivity  extends AppCompatActivity {
    private EditText emaile, passworde, passwordConf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_a);
        UserManager.init(this);

        TextView toolbarTitle = findViewById(R.id.toolbar_title);
        toolbarTitle.setText("Reset Password");
        findViewById(R.id.back_button).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        emaile = findViewById(R.id.emailEdit);

        emaile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                String email = emaile.getText().toString().trim();
                findViewById(R.id.buttonContinue).setEnabled(!email.isEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }

    public void checkEmail(View view) {
        String email = emaile.getText().toString().trim();

        // Проверка на валидность Email
        if (!email.matches("[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
            Toast.makeText(this, R.string.incorrect_email, Toast.LENGTH_SHORT).show();
            return;
        }

        UserManager.User user = UserManager.getUser(email);

        if (UserManager.userExists(email) && user != null) {
            setContentView(R.layout.activity_reset_b);

            passworde = findViewById(R.id.passwordEdit);
            passwordConf = findViewById(R.id.passwordConfEdit);

            Button button = findViewById(R.id.resetPasswordO);

            TextView toolbarTitle = findViewById(R.id.toolbar_title);
            toolbarTitle.setText("Reset Password");
            findViewById(R.id.back_button).setOnClickListener(v -> {
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            });

            passworde.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                    String email = passworde.getText().toString().trim();
                    String email2 = passwordConf.getText().toString().trim();
                    button.setEnabled(!email.isEmpty() && !email2.isEmpty());
                }

                @Override
                public void afterTextChanged(Editable editable) {}
            });

            passwordConf.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                    String email = passworde.getText().toString().trim();
                    String email2 = passwordConf.getText().toString().trim();
                    button.setEnabled(!email.isEmpty() && !email2.isEmpty());
                }

                @Override
                public void afterTextChanged(Editable editable) {}
            });

            button.setOnClickListener(v -> {
                String pass1 = passworde.getText().toString().trim();
                String pass2 = passwordConf.getText().toString().trim();

                // Сравниваем пароль
                if (pass1.equals(pass2)) {
                    if (!user.getPassword().equals(pass1)){
                        UserManager.saveEmail(this, email);
                        UserManager.saveUser(email, pass1, user.getFirstName(), user.getLastName());
                        Toast.makeText(this, "Reset password successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, LoginActivity.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Password already exists", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Если пароль неверный
                    Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show();
                }
            });

        } else {
            Toast.makeText(this, "User with email " + email + " no found.", Toast.LENGTH_SHORT).show();
        }
    }
}