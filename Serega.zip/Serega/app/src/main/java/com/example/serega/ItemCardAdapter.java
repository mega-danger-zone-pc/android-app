package com.example.serega;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemCardAdapter extends RecyclerView.Adapter<ItemCardAdapter.ViewHolder> {
    ArrayList<ItemCard> cards;
    public ItemCardAdapter(ArrayList<ItemCard> seregi) {
        this.cards = seregi;
    }
    @NonNull
    @Override
    public ItemCardAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ItemCardAdapter.ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_card, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ItemCardAdapter.ViewHolder holder, int position) {
        holder.title.setText(cards.get(position).title);
        holder.revievs.setText(String.format("%d Reviews", cards.get(position).reviews));
        holder.ocenka.setText(String.format("%.1f", cards.get(position).ocenka));

        if (cards.get(position).skidka_cena > 0) {
            holder.cenaOld.setVisibility(View.VISIBLE);
            holder.sale.setVisibility(View.VISIBLE);
            holder.cenaOld.setPaintFlags(holder.cenaOld.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            holder.cenaOld.setText(String.format("Rp. %,.0f", cards.get(position).cena));
            holder.cena.setText(String.format("Rp. %,.0f", cards.get(position).skidka_cena));
        }
        else holder.cena.setText(String.format("Rp. %,.0f", cards.get(position).cena));

        holder.ava.setImageResource(cards.get(position).image);

        holder.ava.setOnClickListener(v -> {
            Fragment itemDetailsFragment = new CardFragment();

            Bundle bundle = new Bundle();
            bundle.putParcelable("itemCard", cards.get(position));
            itemDetailsFragment.setArguments(bundle);

            ((MainActivity) v.getContext()).getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainerView, itemDetailsFragment)
                    .addToBackStack(null)
                    .commit();
        });
    }

    @Override
    public int getItemCount() {
        return cards.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView title, revievs, ocenka, cena, cenaOld;
        public ImageView ava, sale;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.titleName);
            cena = itemView.findViewById(R.id.cena);
            sale = itemView.findViewById(R.id.salo);
            cenaOld = itemView.findViewById(R.id.cenaold);
            revievs = itemView.findViewById(R.id.reviewsText);
            ocenka = itemView.findViewById(R.id.ratingOcenka);
            ava = itemView.findViewById(R.id.imageview);
        }
    }
}
