package com.example.serega;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    private EditText fullname, emaile, passworde, passwordConf;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        UserManager.init(this);

        fullname = findViewById(R.id.fullnameEdit);
        emaile = findViewById(R.id.emailEdit);
        passworde = findViewById(R.id.passwordEdit);
        passwordConf = findViewById(R.id.passwordConfEdit);
        button = findViewById(R.id.buttonReg);

        fullname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                checkFields();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
        emaile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                checkFields();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
        passworde.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                checkFields();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
        passwordConf.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                checkFields();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }
    private void checkFields() {
        String email = emaile.getText().toString().trim();
        String fullnamee = fullname.getText().toString().trim();
        String passwordConfe = passwordConf.getText().toString().trim();
        String password = passworde.getText().toString().trim();

        // Если оба поля не пустые, кнопка активна
        button.setEnabled(!email.isEmpty() && !password.isEmpty() && !passwordConfe.isEmpty() && !fullnamee.isEmpty());
    }

    public void seregain(View view) {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    public void RegContinue(View view) {
        String fullName = fullname.getText().toString().trim();
        String email = emaile.getText().toString().trim();
        String password = passworde.getText().toString().trim();
        String confirmPassword = passwordConf.getText().toString().trim();

        // Проверка на заполненность полей
        if (fullName.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, R.string.incorrect_all_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        String[] nameParts = fullName.split(" ");
        if (nameParts.length < 2) {
            Toast.makeText(this, R.string.incorrect_name, Toast.LENGTH_SHORT).show();
            return;
        }

        String firstName = nameParts[0];
        String lastName = nameParts[1];

        // Проверка на валидность Email
        if (!email.matches("[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
            Toast.makeText(this, R.string.incorrect_email, Toast.LENGTH_SHORT).show();
            return;
        }

        // Проверка на совпадение паролей
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, R.string.password_incorret, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!UserManager.userExists(email)) {
            UserManager.saveEmail(this, email);
            UserManager.saveUser(email, password, firstName, lastName);
            Toast.makeText(RegisterActivity.this, R.string.registration_was_suc, Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            Toast.makeText(this, "User with email " + email + " already exists.", Toast.LENGTH_SHORT).show();
        }
    }
}
