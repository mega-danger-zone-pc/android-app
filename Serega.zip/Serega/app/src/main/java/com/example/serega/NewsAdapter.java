package com.example.serega;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

    public class NewsAdapter extends  RecyclerView.Adapter<NewsAdapter.ViewHolder> {
    ArrayList<News> cards;
    public NewsAdapter(ArrayList<News> seregi) {
        this.cards = seregi;
    }
    @NonNull
    @Override
    public NewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NewsAdapter.ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_news, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull NewsAdapter.ViewHolder holder, int position) {
        holder.zagolovok.setText(cards.get(position).zagolovok);
        holder.textik.setText(cards.get(position).textik);
        holder.data.setText(cards.get(position).data);
        holder.kartinka.setImageResource(cards.get(position).kartinka);
    }

    @Override
    public int getItemCount() {
        return cards.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView zagolovok, textik, data;
        public ImageView kartinka;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            zagolovok = itemView.findViewById(R.id.top_investm);
            textik = itemView.findViewById(R.id.in_the_late);
            data = itemView.findViewById(R.id.economy_15_);
            kartinka = itemView.findViewById(R.id.kartinka);
        }
    }
}