package com.example.serega;

import android.content.Context;
import android.content.SharedPreferences;

public class UserManager {
    private static final String PREF_NAME = "user_prefs";
    public static void saveEmail(Context context, String email) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("email", email);
        editor.apply();
    }

    public static String getSavedEmail(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString("email", null);
    }
    public static boolean isUserLoggedIn(Context context) {
        return getSavedEmail(context) != null && !getSavedEmail(context).isEmpty();
    }
    private static SharedPreferences sharedPreferences;

    // Инициализация SharedPreferences
    public static void init(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }
    public User getUserLoginned(Context context) {
        String email = getSavedEmail(context);
        if (userExists(email)) {
            String password = sharedPreferences.getString(email + ":password", null);
            String firstName = sharedPreferences.getString(email + ":firstName", null);
            String lastName = sharedPreferences.getString(email + ":lastName", null);

            if (password != null && firstName != null && lastName != null) {
                return new User(firstName, lastName, email, password);
            }
        }
        return null;
    }
    // Сохранение данных пользователя
    public static void saveUser(String email, String password, String firstName, String lastName) {
        if (sharedPreferences == null) {
            throw new IllegalStateException("UserManager is not initialized. Call init() first.");
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Сохранение данных пользователя
        editor.putString(email + ":password", password);
        editor.putString(email + ":firstName", firstName);
        editor.putString(email + ":lastName", lastName);
        editor.apply(); // Сохраняем данные асинхронно
    }

    // Проверка, существует ли пользователь с таким email
    public static boolean userExists(String email) {
        if (sharedPreferences == null) {
            throw new IllegalStateException("UserManager is not initialized. Call init() first.");
        }

        return sharedPreferences.contains(email + ":password"); // Проверяем, есть ли пароль для данного email
    }

    // Получение данных пользователя
    public static User getUser(String email) {
        if (sharedPreferences == null) {
            throw new IllegalStateException("UserManager is not initialized. Call init() first.");
        }

        if (userExists(email)) {
            String password = sharedPreferences.getString(email + ":password", null);
            String firstName = sharedPreferences.getString(email + ":firstName", null);
            String lastName = sharedPreferences.getString(email + ":lastName", null);

            if (password != null && firstName != null && lastName != null) {
                return new User(firstName, lastName, email, password);
            }
        }
        return null;
    }

    // Вспомогательный класс для хранения данных пользователя
    public static class User {
        private String firstName;
        private String lastName;
        private String email;
        private String password;

        public User(String firstName, String lastName, String email, String password) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.password = password;
        }

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public String getEmail() {
            return email;
        }

        public String getPassword() {
            return password;
        }
    }
}
