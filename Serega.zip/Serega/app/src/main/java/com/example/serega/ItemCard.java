package com.example.serega;

import android.os.Parcel;
import android.os.Parcelable;

public class ItemCard implements Parcelable {
    public String title;
    public double cena, skidka_cena;
    public float ocenka;
    public int image, reviews;


    public ItemCard(String title, double cena, double skidka_cena, float ocenka, int reviews, int image){
        this.title = title;
        this.cena = cena;
        this.ocenka = ocenka;
        this.reviews = reviews;
        this.image = image;
        this.skidka_cena = skidka_cena;
    }

    // Реализация Parcelable
    protected ItemCard(Parcel in) {
        title = in.readString();
        cena = in.readDouble();
        skidka_cena = in.readDouble();
        ocenka = in.readFloat();
        reviews = in.readInt();
        image = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeDouble(cena);
        dest.writeDouble(skidka_cena);
        dest.writeFloat(ocenka);
        dest.writeInt(reviews);
        dest.writeInt(image);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ItemCard> CREATOR = new Creator<ItemCard>() {
        @Override
        public ItemCard createFromParcel(Parcel in) {
            return new ItemCard(in);
        }

        @Override
        public ItemCard[] newArray(int size) {
            return new ItemCard[size];
        }
    };
}