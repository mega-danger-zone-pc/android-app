package com.example.serega;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomeFragment extends Fragment {
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ViewPager2 reclama1 = view.findViewById(R.id.recyclerViewReclama);
        List<Integer> images = Arrays.asList(
                R.drawable.reclama,
                R.drawable.reclama2,
                R.drawable.reclama3,
                R.drawable.reclama4
        );
        reclama1.setAdapter(new ImageAdapter(images));
        reclama1.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
        reclama1.setOffscreenPageLimit(1);

        RecyclerView recyclerViewFeatured = view.findViewById(R.id.recyclerViewFeatured);
        ArrayList<ItemCard> items = new ArrayList<>();
        items.add(new ItemCard("TMA-2 HD Wireless", 1500000.0, 0, 4.6f, 86, R.drawable.item1));
        items.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 86, R.drawable.item2));
        items.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 44, R.drawable.item3));
        items.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 86, R.drawable.item2));
        recyclerViewFeatured.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerViewFeatured.setAdapter(new ItemCardAdapter(items));

        RecyclerView recyclerViewBestSeller = view.findViewById(R.id.recyclerViewBestSeller);
        ArrayList<ItemCard> items_best = new ArrayList<>();
        items_best.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 44, R.drawable.item3));
        items_best.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 86, R.drawable.item2));
        items_best.add(new ItemCard("TMA-2 HD Wireless", 1500000.0, 0, 4.6f, 86, R.drawable.item1));
        items_best.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 86, R.drawable.item2));
        recyclerViewBestSeller.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerViewBestSeller.setAdapter(new ItemCardAdapter(items_best));

        RecyclerView recyclerNewArrivals = view.findViewById(R.id.recyclerNewArrivals);
        ArrayList<ItemCard> items_newarr = new ArrayList<>();
        items_newarr.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 44, R.drawable.item3));
        items_newarr.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 86, R.drawable.item2));
        items_newarr.add(new ItemCard("TMA-2 HD Wireless", 1500000.0, 0, 4.6f, 86, R.drawable.item1));
        items_newarr.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 86, R.drawable.item2));
        recyclerNewArrivals.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerNewArrivals.setAdapter(new ItemCardAdapter(items_newarr));

        RecyclerView recyclerTopRated = view.findViewById(R.id.recyclerTopRated);
        ArrayList<ItemCard> items_top = new ArrayList<>();
        items_top.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 44, R.drawable.item3));
        items_top.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 86, R.drawable.item2));
        items_top.add(new ItemCard("TMA-2 HD Wireless", 1500000.0, 0, 4.6f, 86, R.drawable.item1));
        items_top.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 0, 4.6f, 86, R.drawable.item2));
        recyclerTopRated.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerTopRated.setAdapter(new ItemCardAdapter(items_top));

        RecyclerView recyclerSpecialOffers = view.findViewById(R.id.recyclerSpecialOffers);
        ArrayList<ItemCard> items_spec = new ArrayList<>();
        items_spec.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 1000000.0, 4.6f, 44, R.drawable.item1));
        items_spec.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 1000000.0, 4.6f, 86, R.drawable.item2));
        items_spec.add(new ItemCard("TMA-2 HD Wireless", 1500000.0, 1000000.0, 4.6f, 86, R.drawable.item3));
        items_spec.add(new ItemCard("TMA-2 HD Wireless", 2500000.0, 1000000.0, 4.6f, 86, R.drawable.item2));
        recyclerSpecialOffers.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerSpecialOffers.setAdapter(new ItemCardAdapter(items_spec));


        RecyclerView list_news = view.findViewById(R.id.list_news);
        ArrayList<News> items_News = new ArrayList<>();
        items_News.add(new News("Philosophy That Addresses Topics Such As Goodness", "Agar tetap kinclong, bodi motor ten...", "13 Jan 2021", R.drawable.news1));
        items_News.add(new News("Philosophy That Addresses Topics Such As Goodness", "Agar tetap kinclong, bodi motor ten...", "13 Jan 2021", R.drawable.news2));
        items_News.add(new News("Philosophy That Addresses Topics Such As Goodness", "Agar tetap kinclong, bodi motor ten...", "13 Jan 2021", R.drawable.news3));
        list_news.setLayoutManager(new LinearLayoutManager(getContext()));
        list_news.setAdapter(new NewsAdapter(items_News));
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }
}