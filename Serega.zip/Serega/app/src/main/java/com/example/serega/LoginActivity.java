package com.example.serega;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText emaile, passworde;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        UserManager.init(this);

        emaile = findViewById(R.id.emailEdit);
        passworde = findViewById(R.id.passwordEdit);
        button = findViewById(R.id.buttonSign);

        emaile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                checkFields();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
        passworde.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                checkFields();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }
    private void checkFields() {
        String email = emaile.getText().toString().trim();
        String password = passworde.getText().toString().trim();

        // Если оба поля не пустые, кнопка активна
        button.setEnabled(!email.isEmpty() && !password.isEmpty());
    }

    public void signup(View view) {
        startActivity(new Intent(this, RegisterActivity.class));
        finish();
    }

    public void LogContinue(View view) {
        String email = emaile.getText().toString().trim();
        String password = passworde.getText().toString().trim();

        // Проверка, что введены все данные
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginActivity.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Проверка существования пользователя с таким email
        if (UserManager.userExists(email)) {
            // Получаем пользователя
            UserManager.User user = UserManager.getUser(email);

            // Сравниваем пароль
            if (user != null && user.getPassword().equals(password)) {
                UserManager.saveEmail(this, email);
                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                // Если пароль неверный
                Toast.makeText(LoginActivity.this, "Incorrect password", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Если пользователь с таким email не найден
            Toast.makeText(LoginActivity.this, "No user found with this email", Toast.LENGTH_SHORT).show();
        }
    }

    public void forgotPass(View view) {
        startActivity(new Intent(this, ResetActivity.class));
        finish();
    }
}
